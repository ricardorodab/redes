#! /usr/bin/env python


#####################################################
# PURPOSE: Archivo con constantes                   #
#                                                   #
# Vilchis Dominguez Miguel Alonso                   #
#       <mvilchis@ciencias.unam.mx>                 #
#                                                   #
# Notes:                                            #
#                                                   #
# Copyright   16-08-2015                            #
#                                                   #
# Distributed under terms of the MIT license.       #
#####################################################
import pyaudio
CHAT_WIDTH = 500
CHAT_HEIGHT = 500
LOGIN_WIDTH = 250
LOGIN_HEIGTH = 200
CALL_WIDTH = 250
CALL_HEIGTH = 200
DEFAULT_POSTION_X =350
DEFAULT_POSTION_Y =350
INFO_HEIGTH = 40
INFO_WIDTH = CHAT_WIDTH
CHAT_PORT = 5000
### Audio
#TODO 
### Video
#TODO
### Directorio
SERVER_PORT =  7000
MESSAGE_IP = 0
MESSAGE_PORT = 1
MESSAGE_TEXT = 2
WIDGET = 'widget'
NAME_CONTACT = 'username'
IP_CONTACT = 'ip_contact'
PORT_CONTACT = 'port_contact'
TABLE_ITEMS = 2
FIRST_ITEM = 0
SECOND_ITEM = 1
